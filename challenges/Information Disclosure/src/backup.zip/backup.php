<!DOCTYPE html>
<html>
<head>
<link href='https://fonts.googleapis.com/css?family=Barlow' rel='stylesheet'>
</head>
<body style="font-family: 'Barlow';">

    <section>
      <img src="/static/lightbulb-2891372-2409779.png">
      <link rel="stylesheet" href="/static/css.css">
      <h1 style="text-align:center;">VIS{Sometimes_Dev_f0rget_IMPORTANT_Files!}</h1>
    </section>
    <div class="c1"></div>
    <div class="c2"></div>

</body>
</html>
